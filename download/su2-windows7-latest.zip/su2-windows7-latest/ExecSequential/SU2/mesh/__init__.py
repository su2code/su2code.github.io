# SU2/mesh/__init__.py

__all__ = ['adapt']

from SU2.mesh import adapt

from SU2.mesh.tools import *
